#  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
###  İletişim;
-   Discord: https://discord.gg/7hbzSGTYeZ
-   Mail: ognitorenks@gmail.com
-   Site: [https://ognitorenks.blospot.com](https://ognitorenks.blospot.com)


<details><B><summary> Versiyon 4.2 ► 19.06.2024 </B></summary>

	• İmaj mount işlemi sonrası test için ekleyip unuttuğum 'pause' komutu kaldırıldı.
	• "Format sonrası ilk açılışa batch script ekle" bölümündeki tüm hatalar giderildi. Sorunsuz bir şekilde çalışması sağlandı.

<details><B><summary> Versiyon 4.1 ► 25.05.2024</B></summary>

	• "OgnitorenKs_Reader" başlığında nizami görüntü için kodlar düzenlendi.
	• "Hepsi bir arada Windows Hazırla [AIO]" bölümüne farklı mimari sürümlerin x86 üzerinde birleştirilmesiyle ilgili uyarı mesajı eklendi.
		• Ayrıca tüm sürümlerin görüntülenmesi için Ana sürüm imajında "Sources" klasöründe "ei.cfg" dosyası eklemesi için yeni kodlar eklendi.
	• Komut ekranı başlığına programın sürüm bilgisi eklendi.
	• Dil dosyasında bazı düzenlemeler yapıldı.
	• "Format sonrası batch script ekle" bölümünde mount kontrol komutu eklendi.

</details><details><B><summary> Versiyon 4.0 ► 23.05.2024</B></summary>

	• Genel olarak bazı kodlar revize edildi.
	• Dosya konumunu belirten 'L' değişkeni 'Konum' olarak düzenlendi.
	• Regedit dönüştürme kodlarında yer alan hatalar giderildi.
	• "Modelong2" başlığı tek bir bölümde kullandıldığı için ilgili bölüme alınıp başlık iptal edildi.
	• install.wim/esd dosya yolu kontrol bölümünde ESD için yapılan kontrollerde komutlara ekleme yapıldı.
	• Hata mesajlarını göstermesi için oluşturduğum 'LE' başlığı 'Error_Window' olarak değiştirildi.
	• 'Mount_Check' ve 'Mount_Check2' başlıkları birleştirildi. Bağlı kodlar revize edildi.
	• Dil kodları revize edildi. Eski sisteme ait dil kodları kaldırıldı.
	• Regedit entegrasyonu bölümünde bazı dönüştürme eksiklikleri giderildi.
	• 'Windows Setup düzenle' bölümü eklendi.
		• Lerup lauch bar ve programların hızlıca eklenmesi. İlk kurulumda dosyayı internetten indirir.
		• Windows 11 eski donanım engellemesini kaldırmak için bypass kayıtlarını entegre eder.
		• VMD sürücüleri ekler. İlk kurulumda dosyayı internetten indirir.
		• Setup özelleştirmesiyle alakalı dosyaları değiştirir. 3 adet dosya ile sınırlandırılmıştır.
	• Regedit ekleme bölümü için özel başlıklar oluşturuldu.
	
</details>